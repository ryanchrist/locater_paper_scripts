## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, eval = TRUE-------------------------------------------------------
set.seed(7)

library(locater)
library(kalis)

## ----cache_haplotypes, eval=TRUE----------------------------------------------
# Load simulated haplotypes and recombination map
CacheHaplotypes(SmallHaps)
map <- SmallMap

## ----simulate_phenotypes, eval=TRUE-------------------------------------------
# Simulate 20 Phenotypes where only the first is driven by local causal variants

n <- N()/2 # number of samples
m <- 20 # number of phenotypes

y <- matrix(rnorm(n*m),n,m)
g <- QueryCache(c(204,205,207,210)) # c(204,205,207) are indices of causal loci
g <- g[,seq(1,N(),2)] + g[,seq(2,N(),2)]

y[,1] <- y[,1] + colSums((g)*c(150,10,30,100)#c(150,8,20)
                         /rowSums(g))
A <- matrix(1,n,1) # background covariate matrix is just an index here

## ----find_target_variants, eval=TRUE------------------------------------------
# Determine target loci based on SMT
smt.res <- TestCachedMarkers(y, A = A)
target.loci <- FindTargetVars(map, min.cM = 0.1, initial.targets = smt.res, smt.thresh = 3)

## ----testloci, eval=TRUE------------------------------------------------------

# Specify kalis parameters 
pars <- Parameters(CalcRho(diff(map),s = 0.0001),mu = 1e-16) # specify HMM parameters

# Specify a list of optional arguments to control exactly how locater tests each position. If more than one combination of testing parameters is desired, a data.frame with multiple rows can be given and locater will efficiently evaluate all testing options.
test.opts <- data.frame("max.k" = 128)

#set.seed(53)
res <- TestLoci(y, pars, target.loci = target.loci, test.opts = test.opts)

## ----visualize_manhattan, eval=TRUE-------------------------------------------
smt.p1 <- smt.res[,1]
res.p1 <- res[phenotype==1,c("locus.idx","tot")]

COLORS <- palette.colors(3)
plot(0,0, type = "n", 
     ylim=range(pretty(c(0,max(c(smt.p1,res.p1$tot),na.rm=T)))),
     xlim = range(pretty(map)),
     las=1,bty="n",
     ylab = "-log10 p-value", xlab = "cM position")
points(map,smt.p1,col=COLORS[1],pch=20)
points(map[res.p1$locus.idx],res.p1$tot,col=COLORS[2],pch=20)
legend("topleft",legend = c("SMT","LOCATER"),
       fill = COLORS, bty = "n")

## ----calling_distill, eval=TRUE-----------------------------------------------

p <- 50 # number of inferred genotypes
num_true_causal <- nrow(g)

x <- cbind(t(g),Matrix::sparseMatrix(i = sample.int(n,10*(p-num_true_causal),replace = TRUE), 
                          j = rep(seq_len(p-num_true_causal), each=10),
                          x = rep(c(rep(1,8),2,2), (p-num_true_causal)), 
                          dims = c(n,p-num_true_causal)))

Q <- qr.Q(qr(A))

sd_res <- distill_pivot_par(y, x, Q, max_num_causal = 16)


## ----visualize_sd_results, eval=TRUE------------------------------------------
barplot(-log10(sd_res$p_value),names.arg=1:m,xlab="Phenotype",ylab="-log10 SD p-value",las=1,cex.names=0.8)

## ----calling_test_clade_mat, eval=TRUE----------------------------------------
M <- as.matrix(tcrossprod(x))
q_res <- TestCladeMat(y, M, Q, k = 0)

## ----visualize_qform_results, eval=TRUE---------------------------------------
barplot(q_res$qform,names.arg=1:m,xlab="Phenotype",ylab="-log10 Quadratic Form p-value",las=1,cex.names=0.8)

## ----show_qform_datatable, eval=TRUE------------------------------------------
print(q_res[1:5,])

## ----calling_test_clade_mat_precise, eval=TRUE--------------------------------
q_res_precise <- TestCladeMat(y, M, Q, k = 10)

## ----visualize_qform_results_precise, eval=TRUE-------------------------------
barplot(q_res_precise$qform,names.arg=1:m,xlab="Phenotype",ylab="-log10 Quadratic Form p-value",las=1,cex.names=0.8)

## ----show_qform_datatable_precise, eval=TRUE----------------------------------
print(q_res_precise[1:5,])

