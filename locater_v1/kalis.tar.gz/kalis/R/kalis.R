#' @import dplyr
#' @import checkmate
#' @importFrom glue glue glue_collapse
#' @importFrom rlang duplicate
#' @importFrom digest digest
#' @importFrom stats sd
#'
#' @useDynLib kalis, .registration = TRUE, .fixes = "CCall_"
NULL
