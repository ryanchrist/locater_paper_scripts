#ifndef R_COMPUTESTATUS_H
#define R_COMPUTESTATUS_H

#define R_NO_REMAP
#include <R.h>
#include <Rinternals.h>

SEXP ComputeStatus();

SEXP VectorBitWidth();

#endif
