## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
collapse = TRUE,
comment = "#>"
)

## ----load.data, results = "hide", message=FALSE, eval=FALSE-------------------
#  require(kalis)
#  CacheHaplotypes("my.hap.gz")

