library(testthat)
library(kalis)

test_check("kalis")
